

python stereo_depth.py \
    --calibration_file ./configs/stereo.yml \
    --left_source ./data/left.jpg \
    --right_source ./data/right.jpg \
    --pointcloud_dir ./output/
